<div class="entry-meta entry-footer">
	<span class="entry-categories"><?php _e('Posted in: ', AZ_THEME_NAME) ?> <?php the_category(', ') ?></span>
	<span class="entry-tags"><?php the_tags( __('Tagged:', AZ_THEME_NAME) . ' ', ', ', ''); ?></span>
</div>