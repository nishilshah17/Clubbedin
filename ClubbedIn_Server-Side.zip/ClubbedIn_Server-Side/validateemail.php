<?php
header("access-control-allow-origin: *");

include 'mysqlconnect.php';

$dbserver = mysql_connect($dbhost, $dbuser, $dbpass)
    or die("Unable to connect to MySQL: " . mysql_error());
mysql_select_db($db)
    or die("Unable to select database: " . mysql_error());

$email = $_POST['signupemail'];

$result = mysql_query('SELECT * FROM user WHERE email = "'.$email.'"');

if(mysql_num_rows($result) > 0) {
	$message = 'no';
}
else {
	$message = 'yes';
}

echo $message;


?>