<form method="get" id="searchform" action="<?php echo home_url(); ?>/">
	<fieldset>
		<input type="text" name="s" value="" placeholder="<?php _e('To search type and hit enter...', AZ_THEME_NAME); ?>" />
    </fieldset>
</form>